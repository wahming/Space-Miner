function update_graphical_fabricator_list() {
	if ($('#fabrication-menu').css('display') == 'block') {
		for (var i = 0; i < fabricator_types.length; i++) {
			for (var j = 0; j < fabricator_types[i].collection.length; j++) {
				var fab = fabricator_types[i].collection[j];
				var div_name = "div-fabricate-" + fab.uid;
				document.getElementById(div_name + "-progress").value = fab.current_product_progress;
				$('#' + div_name + "-status").text (fab.status);
				if (fab.active == false && fab.current_product_progress == 0) {
					$('#' + div_name + "-resume").show();
				}
				$('#' + div_name + "-quantity").text(fab.current_product == null? "-" : fab.current_product.quantity);
			}
		}
	}
}

function init_fabricator_list() {	
	$('#central-panel').append("<div id='fabrication-menu' class='central-menu'></div>");
}

function get_fabricable_dropdown (div_name, selected) {
	var result = "<select id='" + div_name + "-dropdown' size=8>";
	
	if (selected == null) {
		result += "<option value='None' selected>Nothing</option>";
	} else {result += "<option value='None'>Nothing</option>";}
	
	for (var i = 0; i < fabricables.length; i++) {
		if (fabricables[i].id == selected) {
			result += "<option value='" + fabricables[i].id + "' selected>" + fabricables[i].name + "</option>";
		} else {result += "<option id='" + div_name + "-option-" + i + "' value='" + fabricables[i].id + "'>" + fabricables[i].name + "</option>";}
	
		$(document).on ('mouseenter', "#" + div_name + "-option-" + i, function (e) {
			find_object (e.currentTarget.value).info();
		});
		
		$(document).on ('mouseleave', "#" + div_name + "-option-" + i, function (e) {
			$('#info-table').empty();
		});
	}
	result += "</select>";
	
	
	return result;
}

function add_to_fabricator_list (fab) {
	var div_name = "div-fabricate-" + fab.uid;
	
	$('#fabrication-menu').append("<div class='list-div' id='" + div_name + "'></div>");
	
	$('#' + div_name).append ("<b>" + fab.name + "</b><br/><br/>");
	
	$('#' + div_name).append ("<table style='float:left;'><tr><td style='padding:0px; vertical-align:middle'>Currently producing: </td><td style='padding:0px;'  id='" + div_name + "-product'></td></tr></table>");
	$('#' + div_name).append ("<span style='float: right'>Quantity: <span id='" + div_name + "-quantity'>-</span></span><br/>");
	$('#' + div_name).append ("<span style='float: right'><input id='" + div_name + "-checkbox' type='checkbox'>Loop production</span>");
	$('#' + div_name).append ("<div id='" + div_name + "-buttons' style='clear:left'></div>");
	$('#' + div_name + '-buttons').append ("<a href='#' id='" + div_name + "-change-product'>(Change product)</a>");
	$('#' + div_name + '-buttons').append ("<a href='#' id='" + div_name + "-confirm' title='test'>(Confirm)</a>");
	$('#' + div_name + '-buttons').append ("<a href='#' id='" + div_name + "-cancel'>(Cancel)</a>");
	
	
	$('#' + div_name).append ("<br/>");
	$('#' + div_name).append ("Status: <span id='" + div_name + "-status'></span>&nbsp;<span id='" + div_name + "-resume'><a href='#'>(Resume)</a></span><br/>");
	$('#' + div_name).append ("<progress id='" + div_name + "-progress' class='progress' value=0 max_value=0></progress>");
	$('#' + div_name).append ("<p>-----</p>");
	

	$('#' + div_name + "-confirm").hide();
	$('#' + div_name + "-cancel").hide();
	$('#' + div_name + "-resume").hide();
	$('#' + div_name + "-product").text(fab.current_product == null? "Nothing" : fab.current_product);
	
	
	// Add button listener
	(function(fab, div_name) {
		$('#' + div_name + '-checkbox').click(function() {
			var $this = $(this);
			if ($this.is(':checked')) {
				fab.loop_production = true;
				// the checkbox was checked 
			} else {
				fab.loop_production = false;
				// the checkbox was unchecked
			}
		});
	}(fab, div_name));
		
	(function(fab, div_name) {
		$('#' + div_name + '-change-product').on('click', function () {
			$('#' + div_name + "-product").empty();
			$('#' + div_name + "-product").append (get_fabricable_dropdown (div_name, fab.current_product));
			$('#' + div_name + '-change-product').hide();
			$('#' + div_name + '-confirm').show();
			$('#' + div_name + '-cancel').show();
		});
	}(fab, div_name));
	
	(function(fab, div_name) {
		$('#' + div_name + '-confirm').on('click', function () {
			var selected = $('#' + div_name + "-dropdown").val();
			if (fab.current_product != selected) {
				if (selected != 'None') {
					fab.produce (selected);
					document.getElementById(div_name + "-progress").max = fab.current_product_build_cost;
				} else {
					fab.produce (null);
					document.getElementById(div_name + "-progress").max = 0;
				}
			}
			
			$('#' + div_name + "-product").text(fab.current_product == null? "Nothing" : fab.current_product.name);
			$('#' + div_name + '-confirm').hide();
			$('#' + div_name + '-cancel').hide();
			$('#' + div_name + "-dropdown").remove();
			$('#' + div_name + '-change-product').show();
			$('#' + div_name + "-resume").hide();
		});
	}(fab, div_name));
	
	(function(div_name) {
		$('#' + div_name + '-cancel').on('click', function () {
			$('#' + div_name + "-product").text(fab.current_product == null? "Nothing" : fab.current_product.name);
			$('#' + div_name + '-confirm').hide();
			$('#' + div_name + '-cancel').hide();
			$('#' + div_name + "-dropdown").remove();
			$('#' + div_name + '-change-product').show();
		});
	}(div_name));	
	
	(function(fab, div_name) {
		$('#' + div_name + '-resume').on('click', function () {
			$('#' + div_name + "-resume").hide();
			fab.active = true;
		});
	}(fab, div_name));
}


