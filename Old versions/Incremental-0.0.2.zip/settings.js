//Settings

debug = true;
tick_length = 50;


// Global variables

var glob = [];					// List of all classes/objects
var fabricator_types = [];		// List of fabricator classes - NOT fabricators!
var fabricables = [];			// List of fabricable objects
var furnace_types = [];			// List of furnace classes - NOT furnaces!
var ores = [];					// List of smeltable ores. Should all be basic resources
var resources = [];				// List of all resources
var game_state;					// In-game values

var glob_arrays = [fabricator_types, fabricables, furnace_types, ores, resources];