function find_object (name) {
	for (var i = 0; i < glob.length; i++) {
		if (glob[i].id == name) {
			return glob[i];
		} 
	}
	if (name == null) {return null;}
	
	console.log ("No such object! Called from: " + arguments.callee.caller);
	return null;
}

function affordable (cost) {
	for (var i = 0; i < cost.length; i++) {
		if (cost[i][0].quantity < cost[i][1]) {
			return false;
		}
	}
	return true;
}

var game_object = {
	quantity : 0,
	description : "If you're seeing this, there's a bug. Please report.",
	name : "Game object root class",
	id : "game_object",					// No spaces, or weird html breaking symbols
	flags : [],
	production : [],
	cost : [],							// Cost to build/fabricate/whatever
	consumption : [],
	storage : [],
	start_quantity : 0,
	storage_used : 0,
	buildable : false,					// Should it show up in build menu
	collection : [],					// Array of instances of this object
	fabricable : false,					// Built in fabricator?
	toggleable : false,					// Can you enable/disable?
	build_point_cost : 0,				// How long/difficult it is to build
	built_count : 0,					// Total built since game start
	max_load : 1,						// Used for furnaces only, at the moment
	current_load : 0,					// How much of capacity is being utilised. E.g. 4 load / 10 capacity
	active : false						// Is it in the game yet?
}

{	// Generic game_object methods
	game_object.create = function () {
		if (this.have_ingredients() && this.buildable){// && has_ingredients) {
			console.log ("mark");
			this.consume_ingredients();
			this.create_free();
		}	
	}
	
	game_object.fabricate = function () {
		if (this.fabricable) {
			if (storage.quantity >= this.storage_used){
				this.create_free();
				return true;
			}
		} else {
			alert ("Error! Attempt to fabricate non-fabricable item");
		}
		return false;
	}
	
	// Should never be called from anywhere else
	game_object.create_free = function () {
		this.quantity++;
		this.built_count++;

		
		for (var i = 0; i < this.storage.length; i++) {
			this.storage[i][0].change_capacity (this.storage[i][1]);
		}
		
		storage.change_quantity (this.storage_used * -1);
	}
	
	game_object.init = function () {
		for (var i = 0; i < this.start_quantity; i++) {
			this.create_free ();
		}
	}
	
	game_object.tick = function () {
		for (var i = 0; i < this.quantity; i++) {
			if (affordable (this.consumption, tick_length/1000) && this.storage_used < storage.quantity) {
				for (var j = 0; j < this.consumption.length; j++) {
					this.consumption[j][0].change_quantity (this.consumption[j][1] * tick_length/1000 * -1);
					this.consumption[j][0].gen_speed[resource_generation_index] -= this.consumption[j][1];
				}
				
				for (var j = 0; j < this.production.length; j++) {
					this.production[j][0].change_quantity (this.production[j][1] * tick_length/1000);
					this.production[j][0].gen_speed[resource_generation_index] += this.production[j][1];
				}
			}
		}
	}
	
	game_object.consume_ingredients = function () {
		var cost = this.cost;
		for (var i = 0; i < cost.length; i++) {
			cost[i][0].change_quantity (-1 * cost[i][1]);
		}
	}
	
	game_object.have_ingredients = function () {
		return affordable (this.cost);
	}
	
	game_object.can_maintain = function () {
		return affordable (this.consumption);
	}
	
	game_object.change_quantity = function (quantity) {
		this.quantity += quantity;
		
		storage.change_quantity (this.storage_used * quantity * -1);
	}
	
	game_object.change_capacity = function (quantity) {
		this.capacity += quantity;
	}
	
	game_object.info = function () {
		$('#info-table').empty();
		
		$('#info-table').append ("<tr><td>Name: </td><td>" + this.name + "</td></tr>");
		$('#info-table').append ("<tr><td>Quantity: </td><td>" + this.quantity + "</td></tr>");
		$('#info-table').append ("<tr><td>Build time: </td><td>" + this.build_point_cost/fabricator.build_rate + " s</td></tr>");
		
		var costs = "";
		for (var i = 0; i < this.cost.length; i++) {
			if (this.cost[i][1] > this.cost[i][0].quantity) {
				costs += "<span style='color: red'>";
			}
			
			costs +=  this.cost[i][1].toFixed(0) + " "  + this.cost[i][0].name + "<br/>"
			
			if (this.cost[i][1] > this.cost[i][0].quantity) {
				costs += "</span>";
			}
		}
	
		$('#info-table').append ("<tr><td>Cost: </td><td>" + costs + "</td></tr>");
		
		if (this.production.length > 0) {
			var production = "";
			for (var i = 0; i < this.production.length; i++) {
				production +=  (this.production[i][1]) + " "  + this.production[i][0].name + "<br/>"
			}
			$('#info-table').append ("<tr><td>Production: </td><td>" + production + "</td></tr>");
		}
	
		if (this.consumption.length > 0) {
			var consumption = "";
			for (var i = 0; i < this.consumption.length; i++) {
				consumption +=  (this.consumption[i][1]) + " "  + this.consumption[i][0].name + "<br/>"
			}
			$('#info-table').append ("<tr><td>Consumption: </td><td>" + consumption + "</td></tr>");
		}
	}
}
/*
if (debug) {
	
	var tester = $.extend (tester, Object.create(game_object));
	glob.push (tester);
	{
		tester.description = "For debugging use";
		tester.name = "Debug test object";
		tester.id = "debugger-object";
		tester.buildable = true;
		tester.production = [["iron_ore", 1000]];
	}
}*/

// Resources
{

	// Template for all resources
	{
		var resource = $.extend (resource, Object.create(game_object));
		{
			resource.flags = ["resource"];
			resource.unit = "kg";			// Noun
			resource.smeltable = false;		// (?) Indicate whether player has the ability to smelt the ore yet
			resource.gen_speed = [];		// Stores info in array on how many resources generated per tick over the past second
			resource.storage_used = 1;
			resource.capacity = 0;
			resource.build_point_cost = 300;
		}
		
		resource.tick = function () {}
		resource.create = function () {}
		
		resource.generation_speed = function () {
			var total = 0;
			for (var i = 0; i < this.gen_speed.length; i++) {
				total += this.gen_speed[i];
			}
			return total / this.gen_speed.length;
		}
		
		resource.smelt = function () {		
			if (this.smeltable) {
				if (storage.quantity >= this.storage_used){
					this.create_free();
					return true;
				}
			} else {
				alert ("Error! Attempt to smelt non-smeltable item");
			}
			return false;
		}
	}
	
	var storage = $.extend (storage, Object.create(resource));
	resources.push (storage);
	{
		storage.name = "Storage";
		storage.id = "storage";
		storage.description = "Storage space. We never quite have enough of it";
		storage.active = true;
		storage.gen_speed = [];
	}
	
	storage.change_quantity = function (quantity) {
		this.quantity += quantity;
	}
	
	storage.change_capacity = function (quantity) {
		this.capacity += quantity;
		this.quantity += quantity;
	}

	var copper_ore = $.extend (copper_ore, Object.create(resource));
	ores.push (copper_ore);
	resources.push (copper_ore);
	glob.push (copper_ore);
	{
		copper_ore.name = "Copper ore";
		copper_ore.id = "copper_ore";
		copper_ore.description = "Smelt in a furnace to produce copper";
		copper_ore.active = true;
		copper_ore.gen_speed = [];
	}
	
	var copper = $.extend (copper, Object.create(resource));
	resources.push (copper);
	glob.push (copper);
	{
		copper.name = "Copper";
		copper.id = "copper";
		copper.description = "A malleable reddish-brown metal, widely used as a conductor";
		copper.cost = [[copper_ore, 3]];
		copper.build_rate = 200;
		copper.active = true;
		copper.smeltable = true;
		copper.gen_speed = [];
	}
	
	var iron_ore = $.extend (iron_ore, Object.create(resource));
	ores.push (iron_ore);
	resources.push (iron_ore);
	glob.push (iron_ore);
	{
		iron_ore.name = "Iron ore";
		iron_ore.id = "iron_ore";
		iron_ore.description = "Smelt in a furnace to produce copper";
		iron_ore.active = true;
		iron_ore.gen_speed = [];
	}
	
	var iron = $.extend (iron, Object.create(resource));
	resources.push (iron);
	glob.push (iron);
	{
		iron.name = "Iron";
		iron.id = "iron";
		iron.description = "The basic building material of the modern age";
		iron.cost = [[iron_ore, 3]];
		iron.build_rate = 200;
		iron.start_quantity = 100;
		iron.active = true;
		iron.smeltable = true;
		iron.gen_speed = [];
	}
	
}

// Basic objects
{
	var chassis = $.extend (chassis, Object.create(game_object));
	glob.push (chassis);
	fabricables.push (chassis);
	{
		chassis.name = "Chassis";
		chassis.id = "chassis";
		chassis.description = "Multipurpose robot body";
		chassis.cost = [[iron, 50]];
		chassis.storage_used = 1;
		chassis.fabricable = true;
		chassis.build_point_cost = 1000;
	}
	
	var solar_panel = $.extend (solar_panel, Object.create(game_object));
	glob.push (solar_panel);
	fabricables.push (solar_panel);
	{
		solar_panel.name = "Solar panel";
		solar_panel.id = "solar_panel";
		solar_panel.description = "Solar panel for power generation";
		solar_panel.cost = [[iron, 50]];
		solar_panel.storage_used = 1;
		solar_panel.fabricable = true;
		solar_panel.build_point_cost = 1000;
	}

	var circuit_board = $.extend (circuit_board, Object.create(game_object));
	glob.push (circuit_board);
	fabricables.push (circuit_board);
	{
		circuit_board.name = "Circuit board";
		circuit_board.id = "circuit_board";	
		circuit_board.description = "Basic logic circuit board";
		circuit_board.cost = [[iron, 1], [copper, 1]];
		circuit_board.storage_used = 0.1;
		circuit_board.fabricable = true;
		circuit_board.build_point_cost = 500;
	}
	
	var miner = $.extend (miner, Object.create(game_object));
	fabricables.push(miner);
	glob.push (miner);
	{
		miner.name = "Miner";
		miner.id = "miner";
		miner.description = "A small mining robot that goes from asteroid to asteroid and mines them for precious ores";
		miner.fabricable = true;
		miner.cost = [[chassis, 1], [solar_panel, 1], [circuit_board, 3]];
		miner.production = [[iron_ore, 1], [copper_ore, 1]];
		miner.start_quantity = 2;
		miner.build_point_cost = 500;
	}

	var warehouse = $.extend (warehouse, Object.create(game_object));
	glob.push (warehouse);
	{
		warehouse.name = "Warehouse";
		warehouse.id = "warehouse";
		warehouse.description = "Warehouse for storing goods";
		warehouse.buildable = true;
		warehouse.storage = [[storage, 10000]];
		warehouse.cost = [[iron, 500]];
	}

	var cargo_hold = $.extend (cargo_hold, Object.create(game_object));
	glob.push (cargo_hold);
	{
		cargo_hold.name = "Cargo Hold";
		cargo_hold.id = "cargo_hold";
		cargo_hold.description = "Cargo_hold for storing goods";
		cargo_hold.storage = [[storage, 1000]];
		cargo_hold.start_quantity = 1;
	}
}



// Fabricator
{
	var fabricator = $.extend (fabricator, Object.create(game_object));
	fabricator_types.push (fabricator);
	glob.push (fabricator);
	{
		fabricator.name = "Fabricator";
		fabricator.id = "fabricator";						// No spaces, or weird html breaking symbols
		fabricator.description = "Automated mini-factory to create finished goods from raw materials";
		fabricator.cost = [[solar_panel, 1], [circuit_board, 10], [iron, 100], [copper,5]];
		fabricator.consumption = [];
		fabricator.storage = [];
		fabricator.start_quantity = 1;
		fabricator.buildable = true;
		fabricator.build_rate = 100;
	}

	fabricator.create_free = function () {
		// Generic method code.
		this.quantity++;
		this.built_count++;

		for (var i = 0; i < this.storage.length; i++) {
			this.storage[i][0].capacity += this.storage[i][1];
		}
		
		storage.change_quantity (this.storage_used);
		
		// Class specific
		var fab_instance = Object.create(this);
		fab_instance.uid = this.id + "-" + (this.collection.length+1);
		fab_instance.name += " #" + this.built_count;
		fab_instance.current_product = null;					// What it's currently producing. Just a string of the name
		fab_instance.current_product_progress = 0;				// Function of build_rate and ticks
		fab_instance.current_product_build_cost = 0; 			// How much time/effort the product takes
		fab_instance.current_product_paid = false;				// Has the product cost been paid?
		fab_instance.loop_production = false;
		fab_instance.status = "Stopped";
		fab_instance.active = true;								// Is it active? Note: Can be active and current_product == null. Expected behaviour.
		
		this.collection.push (fab_instance);
		add_to_fabricator_list (fab_instance);
	}
		
	fabricator.produce = function (product) {
		this.current_product = find_object(product);
		this.current_product_progress = 0;
		this.active = true;
		if (product != null) {
			this.current_product_build_cost = this.current_product.build_point_cost;
		}
	}

	fabricator.tick = function () {
		for (var i = 0 ; i < fabricator.collection.length; i++) {
			var fab = fabricator.collection[i];
			
			if (fab.current_product != null && fab.active) {
			
				if (!fab.current_product_paid) {
					if (fab.current_product.have_ingredients()) {
						fab.current_product.consume_ingredients();
						fab.current_product_paid = true;
					} else {
						fab.status = "Waiting for resources";
					}
					
				}
				if (fab.current_product_paid) {
					fab.status = "Fabricating";
					fab.current_product_progress += fab.build_rate * tick_length/1000;
					if (fab.current_product_progress >= fab.current_product_build_cost) {
						if (fab.current_product.fabricate()) {
							fab.current_product_progress = 0;
							fab.current_product_paid = false;
							if (!fab.loop_production) {
								fab.status = "Stopped";
								fab.active = false;
							}
						} else {
							fab.status = "Out of storage space";
						}
					}				
				}	
			}
		}
	}
}	
	
// Furnace
{
	var furnace = $.extend (furnace, Object.create(game_object));
	furnace_types.push (furnace);
	glob.push (furnace);
	{
		furnace.name = "Furnace";
		furnace.id = "furnace";
		furnace.description = "Electric furnace to smelt iron_ores into irons";
		furnace.cost = [[iron, 100]];
		furnace.toggleable = true;
		furnace.start_quantity = 1;
		furnace.buildable = true;
		furnace.build_rate = 100;
		furnace.max_load = 10;
		furnace.collection = [];
	}	
	
	furnace.create_free = function () {
		// Generic method code.
		this.quantity++;
		this.built_count++;

		for (var i = 0; i < this.storage.length; i++) {
			this.storage[i][0].capacity += this.storage[i][1];
		}
		
		storage.change_quantity (this.storage_used);
		
		// Class specific
		var fur_instance = Object.create(this);
		fur_instance.uid = this.id + "-" + (this.collection.length+1);
		fur_instance.name += " #" + this.built_count;
		fur_instance.current_product = null;					// What it's currently producing. Just a string of the name
		fur_instance.current_product_progress = 0;				// Function of build_rate and ticks
		fur_instance.current_product_build_cost = 0; 			// How much time/effort the product takes
		fur_instance.current_product_paid = false;				// Has the product cost been paid?
		fur_instance.loop_production = false;
		fur_instance.status = "Stopped";
		fur_instance.active = true;								// Is it active? Note: Can be active and current_product == null. Expected behaviour.
		
		this.collection.push (fur_instance);
		add_to_furnace_list (fur_instance);
	}
		
	furnace.produce = function (product) {
		this.current_product = find_object(product);
		this.current_product_progress = 0;
		this.active = true;
		if (product != null) {
			this.current_product_build_cost = this.current_product.build_point_cost;
		}
	}
	
	furnace.tick = function () {
		for (var i = 0 ; i < furnace.collection.length; i++) {
			var fur = furnace.collection[i];
			
			if (fur.current_product != null && fur.active) {			
				if (!fur.current_product_paid) {
					fur.load = 0;
					for (var j = 0; j < this.max_load; j++) {
						if (fur.current_product.have_ingredients()) {
							fur.current_product.consume_ingredients();
							fur.current_product_paid = true;
							fur.load++;
						} else if (j == 0) {
							fur.status = "Waiting for resources";
							break;
						}
					}
				}
				
				if (fur.current_product_paid) {
					fur.status = "Smelting (x" + fur.load + ")";
					fur.current_product_progress += fur.build_rate * tick_length/1000;
					fur.current_product.gen_speed[resource_generation_index] += fur.load * fur.build_rate / fur.current_product_build_cost;
					if (fur.current_product_progress >= fur.current_product_build_cost) {
						for (var j = 0; j < fur.load; j++) {
							if (fur.current_product.smelt()) {
								fur.load--;
								j--;
								if (fur.load == 0) {
									fur.current_product_progress = 0;
									fur.current_product_paid = false;
									if (!fur.loop_production) {
										fur.status = "Stopped";
										fur.active = false;
									}
								}
							} else {
								fur.status = "Out of storage space";
							}
						}
					}			
				}
			}
		}
	}
}