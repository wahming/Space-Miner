

// init 

function init_all () {	
	init_objects();
	init_graphics();
}

function init_objects () {
	
	resource_generation_index = 0;
	
	for (var i = 0; i < glob_arrays.length; i++) {
		glob_arrays[i].length = 0;
	}
	
	for (var i = 0; i < glob.length; i++) {
		glob[i].init();
		//var temp = glob[i].init();
		//glob[i] = temp;
	}
}
	
function init_graphics () {
	init_resource_list();
	init_build_list();
	init_products_list();
	init_fabricator_list();
	init_furnace_list();
	init_jettison_list();
}

init_objects ();

for (var i = 0; i < localStorage.length; i++) {	
	if (localStorage.getItem ("glob" + i) != null) {
		var stored_obj = JSON.parse (localStorage.getItem ("glob" + i));
		$.extend (true, find_object (stored_obj.id), stored_obj);
	}
}

for (var i = 0; i < furnace_types.length; i++) {
	for (var j = 0; j < furnace_types[i].collection.length; j++) {
		if (furnace_types[i].collection[j].current_product != null) {
			furnace_types[i].collection[j].current_product = find_object(furnace_types[i].collection[j].current_product.id);
		}
	}
}

for (var i = 0; i < fabricator_types.length; i++) {
	for (var j = 0; j < fabricator_types[i].collection.length; j++) {
		if (fabricator_types[i].collection[j].current_product != null) {
			fabricator_types[i].collection[j].current_product = find_object(fabricator_types[i].collection[j].current_product.id);
		}
	}
}

init_graphics ();

// Run UI update code every 100ms
var timer = (new Date()).getTime();
time_change = 0;
window.setInterval(function () {
	time_change = (new Date()).getTime() - timer + (time_change % tick_length);
	timer = (new Date()).getTime();
		
	for (var i = 1; i <= time_change/tick_length; i++) {
		calculate_resources();
		update_graphical_resource_list();
		update_graphical_build_list();
		update_graphical_fabricator_list();
		update_graphical_products_list();
		update_graphical_furnace_list();
		update_graphical_jettison_list();
	}
}, tick_length);

window.setInterval(function () {
	for (var i = 0; i < glob.length; i++) {
		localStorage["glob"+i] = JSON.stringify(glob[i]);
	}
}, 5000);
