
var jettison_displayed = false;

function update_graphical_jettison_list() {
	if ($('#jettison-menu').css('display') == 'block' && !jettison_displayed) {
		jettison_displayed = true;
		$('#jettison-dropdown').empty();
		for (var i = 0; i < glob.length; i++) {
			if (glob[i].visible && glob[i].quantity > 0) {
				$('#jettison-dropdown').append ("<div class='jettison-opt' onclick='jettison_click(" + i + ")' id='opt" + i + "' onmouseenter=\"glob[" + i + "].info()\">" 
					+ glob[i].name + "</div>");
			}
		}
	}
}

function init_jettison_list() {	
	$('#jettison-menu').remove();
	$('#jettison-menu').empty();
	$('#central-panel').append ("<div id='jettison-menu' class='central-menu'></div>");	
	$('#jettison-menu').append ("<div id='jettison-select' onclick='jettison_drop()'>Jettison:<span id='jettison-select-arrow'>" + '\u25BC' + "</span></div>")
	$('#jettison-menu').append ("<div id='jettison-dropdown' onclick='jettison_drop()'></div>");
	$('#jettison-menu').append ("<div id='jettison-details'></div>");
	
	
}

x = true;
function jettison_drop() {
  if (x == true) {
	$('#jettison-details').empty();
    document.getElementById("jettison-dropdown").style.display = "inline-block";
    x = false;
  } else if (x == false) {
    document.getElementById("jettison-dropdown").style.display = "none";
    x = true;
  }
}

function jettison_click (i) {
	glob[i].info();
	$('#jettison-select').empty();
	$('#jettison-select').append (glob[i].name + "<span id='jettison-select-arrow'>" + '\u25BC' + "</span>");
	$('#jettison-details').append ("<input type='range' id='jettison-quantity' min='0' max='" + glob[i].quantity + "' value=0 oninput='outputUpdate(value)'>");
	$('#jettison-details').append ("<output for='jettison-quantity' id='jettison-indicator'>0</output>");
	$('#jettison-details').append ("<button type='button' id='jettison-confirm' onclick='jettison(" + i + ")'>Jettison!</button>");
}

function outputUpdate(vol) {
	document.querySelector('#jettison-indicator').value = vol;
}

function jettison (i) {
	glob[i].change_quantity (-document.querySelector('#jettison-indicator').value);
	glob[i].info();
	$('#jettison-details').empty();
}














