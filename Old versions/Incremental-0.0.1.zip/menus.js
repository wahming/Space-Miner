function show_tab(tab_name) {
	$('.central-menu').hide();
	$('#' + tab_name).show();
}

$('#menu-buttons').append("<a href='#' id='build-link'>Construction</a>&nbsp;&nbsp;|&nbsp;&nbsp;");
$('#menu-buttons').append('<a href="#" id="products-link">Products</a>&nbsp;&nbsp;|&nbsp;&nbsp;');
$('#menu-buttons').append('<a href="#" id="fabrication-link">Fabricators</a>&nbsp;&nbsp;|&nbsp;&nbsp;');
$('#menu-buttons').append('<a href="#" id="furnace-link">Furnaces</a>&nbsp;&nbsp;|&nbsp;&nbsp;');

// Add button listeners
(function() {
	$('#build-link').on('click', function () {
		show_tab("build-menu");
	});
}());

(function() {
	$('#fabrication-link').on('click', function () {
		show_tab("fabrication-menu");
	});
}());

(function() {
	$('#products-link').on('click', function () {
		show_tab("product-menu");
	});
}());

(function() {
	$('#furnace-link').on('click', function () {
		show_tab("furnace-menu");
	});
}());