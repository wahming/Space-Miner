
function update_graphical_build_list() {
	if ($('#build-menu').css('display') == 'block') {
		for (var i = 0; i < glob.length; i++) {
			if (glob[i].buildable) {
				div_name = "div-build-" + glob[i].id;
				
				if (glob[i].cost.length > 0) {
					$('#' + div_name + "-cost").empty();
					var cost="";
					
					for (j = 0; j < glob[i].cost.length; j++) {
						if (j > 0) {
							cost += "<br/>";
						}
						if (glob[i].cost[j][1] > glob[i].cost[j][0].quantity) {
							cost += "<span style='color:red;'>";
						}
						cost += (glob[i].cost[j][1]) + " " + glob[i].cost[j][0].name;
						
						if (glob[i].cost[j][1] > glob[i].cost[j][0].quantity) {
							cost += "</span>";
						}
					}
					
					$('#' + div_name + "-cost").append(cost);
				}
				$('#' + div_name + "-quantity").text(glob[i].quantity);
			}
			
		}
	}
}

// Create graphical building list
	// Named sectors in here:
	// (Div) div-build-*id*
	// (Button) *div_name*-build-button
	// (Span) *div_name*-quantity
	// (TD) *div_name*-cost
function init_build_list() {
	$('#central-panel').append("<div id='build-menu' class='central-menu'></div>");
	$('#build-menu').show();
	
	for (var i = 0; i < glob.length; i++) {
		if (glob[i].buildable) {
			div_name = "div-build-" + glob[i].id;
			$('#build-menu').append ("<div id='" + div_name + "' class='list-div'>");
			
			details = "<b>" + glob[i].name + "</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
			details += "<span style='float: right'>Quantity: <span id='" + div_name + "-quantity'>" + glob[i].quantity + "</span></span><br/><br/>";
			details += glob[i].description + "<br/>";
			details += "<div style='width:100%; position: relative;'>";
			details += "<div style='float:left; position: relative; width:47%;'>";
			details += "<table>";
			details += "<tr><td valign='top'>Produces: </td><td>";
			if (glob[i].production.length > 0) {
				for (j = 0; j < glob[i].production.length; j++) {
					if (j > 0) {
						details += "<br/>";
					}
					details += glob[i].production[j][1] + " " + resource_id[get_resource_id(glob[i].production[j][0])];
				}
			} else {details += "-";}
			
			details += "<br/></td></tr>";
			details += "<tr><td>Consumes: </td><td>";
			
			if (glob[i].consumption.length > 0) {
				for (j = 0; j < glob[i].consumption.length; j++) {
					if (j > 0) {
						details += "<br/>";
					}
					details += glob[i].consumption[j][1] + " " + resource_id[get_resource_id(glob[i].consumption[j][0])];
				}
			} else {details += "-";}
			
			details += "</td></tr>";
			details += "</table>";
			details += "</div>";
			
			details += "<div style='float: right; position: relative; width:47%'>";
			details += "<table>";
			details += "<tr><td valign='top'>Cost: </td><td id='" + div_name + "-cost'>";
			
			if (glob[i].cost.length > 0) {
				for (j = 0; j < glob[i].cost.length; j++) {
					if (j > 0) {
						details += "<br/>";
					}
					details += (glob[i].cost[j][1] * -1) + " " + glob[i].name;
				}
			} else {details += "-";}
			
			details += "</td></tr>";
			details += "<tr><td>Storage: </td><td>";
			
			if (glob[i].storage.length > 0) {
				for (j = 0; j < glob[i].storage.length; j++) {
					if (j > 0) {
						details += "<br/>";
					}
					details += glob[i].storage[j][1] + " " + glob[i].storage[j][0].name;
				}
			} else {details += "-";}
			
			details += "</td></tr>";
			details += "</table>";
			details += "</div>";
			
			$('#' + div_name).append(details);
			$('#' + div_name).append("<div style='clear:both'><button id='" + div_name + "-build-button'>Build " + glob[i].name + "</button></div>");

			// Add button listener
			(function(item) {
				$('#' + div_name + "-build-button").on('click', function () {
					item.create (1);
				});
			}(glob[i]));
			
			$('#' + div_name).append("<p>-----</p>");
		}
	}
}