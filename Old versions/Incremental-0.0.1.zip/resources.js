// Resources stored as an array 
// Somewhat too much attention to actual IRL figures going on. This is turning into Dwarf Fortress
/*	
var resources = 
	[0,		// Index 0 - Oxygen		// Daily human consumption ~650L
	0,		// Index 1 - Water		// 150L daily
	0,		// Index 2 - Energy		// ~30 kWh daily -> ~100 MJ
	0,		// Index 3 - Food
	0,		// Index 4 - Iron
	0,		// Index 5 - Storage	// Special case. There will be helper methods dealing directly with this.
	0,		// Index 6 - Iron ore
	0,		// Index 7 - Copper ore
	0		// Index 8 - Copper 
	];

var resource_id =			["oxygen",	"water",	"energy",	"food",		"iron",		"storage",			"iron_ore",	"copper_ore",	"copper"];
var resource_names =		["Oxygen",	"Water",	"Energy",	"Food",		"Iron",		"Storage",			"Iron ore",	"Copper ore",	"Copper"];
var resource_unit =			["L",		"L",		"MJ",		"rations",	"kilos",	"m<sup>3</sup>",	"kilos",	"kilos",		"kilos"];
var resource_visible =		[false,		false,		true,		false,		true,		true,				true,		true,			"true"];
var resource_storage =		[0,			0,			0,			0.1,		1,			0,					1,			1,				1];		// How much storage space is used per unit
var smeltable = 			[false,		false,		false,		false,		false,		false,				true,		true,			false];

var resource_generation_index = 0;
var resource_generation_max_index = 1000/tick_length;
var resource_capacity = [];
var resource_generation = [];
for (var i = 0; i < resources.length; i++) {
	resource_capacity.push(0);
	resource_generation.push([]);
}
for (var i = 0; i < resource_generation.length; i++) {
	for (var j = 0; j < resource_generation_max_index; j++) {
		resource_generation[i].push(0);
	}
}

function get_resource_id(name) {
	switch (name) {
    case "oxygen": 
		return 0;
    case "water": 
		return 1;
	case "energy": 
		return 2;
	case "food": 
		return 3;
	case "iron": 
		return 4;
	case "storage": 
		return 5;
	case "iron_ore": 
		return 6;
	case "copper_ore": 
		return 7;
	case "copper": 
		return 8;
	default: 
		alert ("Error: Non-existent resource! Name: " + name);
		abort();
		return -1;
	}
}

function reset_resource_generation () {
	resource_generation_index = resource_generation_index == resource_generation_max_index ? 0 : resource_generation_index;
	for (var i = 0; i < resources.length; i++) {
		resource_generation[i][resource_generation_index] = 0;
	}
}

function get_resource_quantity (name) {return resources [get_resource_id (name)];}
function get_resource_generation (id) {
	var result = 0;
	for (var i = 0; i < resource_generation[id].length; i++) {
		result += resource_generation[id][i];
	}
	return result;
}

function get_resource_capacity (name) {
	var id = get_resource_id (name);
	
	if (resource_storage [id] != 0) {
		return (get_resource_quantity ("storage") + get_resource_quantity (name)) * resource_storage [id];
	} else {
		return resource_capacity [id];
	}
}

function buy (object, quantity) {
	change_resources (object.cost, quantity)
	
	if (object.storage_used > 0) {
		change_resources ([["storage", object.storage_used * -1]], 1);
	}
}

function change_resources (array_costs, quantity) {
	for (var i = 0; i < array_costs.length; i++) {
		var name = array_costs[i][0];
		var id = get_resource_id(name);
		var amount = array_costs[i][1] * quantity;
		
		if (get_resource_quantity (name) + amount > get_resource_capacity (name)) {
			amount = get_resource_capacity (name) - get_resource_quantity(name);
		}
		
		// Reduces storage for resources that use it
		if (resource_storage[id] != 0) {	
			resources[get_resource_id ("storage")] -= amount * resource_storage[id];
		}
		
		resources [get_resource_id (name)] += amount;
	}
	return true;
}

function change_resource_capacity (array_capacities, quantity) {
	for (var i = 0; i < array_capacities.length; i++) {
		name = array_capacities[i][0];
		resource_capacity [get_resource_id (name)] += array_capacities[i][1] * quantity;
		if (name == "storage") {
			resources[get_resource_id(name)] += array_capacities[i][1] * quantity;
		}
	}
}

function change_resource_generation (array_generation, quantity) {
	for (var i = 0; i < array_generation.length; i++) {
		resource_generation [get_resource_id (array_generation[i][0])][resource_generation_index] += array_generation[i][1] * quantity;
	}
}

// Checks if you can afford the cost of an item and have storage for it
function affordable_with_space (object, quantity) {
	if (have_space_for (object, quantity)) {
		return affordable (object.cost, quantity);
	}
	return false;
}

function have_space_for (object, quantity) {
	if (object.storage_used > 0) {
		if (get_resource_quantity ("storage") < object.storage_used * quantity) {
			return false;
		}
	}
	return true;
}

// Checks if you can afford something 
function affordable (array_cost, quantity) {
	for (var i = 0; i < array_cost.length; i++) {
		if (resources[get_resource_id(array_cost[i][0])] < array_cost[i][1] * -1 * quantity) {
			return false;
		}
	}
	return true;
}

function update_graphical_resource_list() {
	for (var i = 0; i < resource_id.length; i++) {
		if (resource_visible[i]) {
			$('#' + resource_id[i] + '-quantity').text((resources[i] < 0 ? -1 * resources[i] : resources[i]).toFixed(0));
			
			if (resource_capacity[i] == 0) {
				$('#' + resource_id[i] + '-quantity').append (" " + resource_unit[i]);
			}
			
			if (resource_capacity[i] > 0) {
				capacity = "/" + resource_capacity[i] + " " + resource_unit[i];
				$('#' + resource_id[i] + '-capacity').empty();
				$('#' + resource_id[i] + '-capacity').append(capacity);
			}
			
			if (resource_generation[i] != 0) {
				var rate = get_resource_generation(i).toFixed(1);
				
				if (rate > 0) {rate = "(+" + rate + "/s)";}
				else {rate = "(" + rate + "/s)";}
				
				$('#' + resource_id[i] + '-rate').text(rate);
			} else {$('#' + resource_id[i] + '-rate').empty();}
		}
	}
};*/

function update_graphical_resource_list() {
	for (var i = 0; i < resources.length; i++) {
		if (resources[i].active) {
			var quantity = resources[i].quantity;
			var id = resources[i].id;
			
			$('#' + id + '-quantity').text((quantity < 0 ? -1 * quantity : quantity).toFixed(0));		// Remove minus signs, usually show up on zeroes (floating point error)
			
			if (resources[i].storage == 0) {
				$('#' + id + '-quantity').append (" " + resources[i].unit);
			}
			
			if (resources[i].capacity > 0) {
				var storage = "/" + resources[i].storage + " " + resources[i].unit;
				$('#' + id + '-storage').empty();
				$('#' + id + '-storage').append(storage);
			}
			
			$('#' + id + '-rate').empty();
			var rate = resources[i].generation_speed().toFixed(1);
			if (rate != 0) {
				if (rate > 0) {rate = "(+" + rate + "/s)";}
				else {rate = "(" + rate + "/s)";}
				
				$('#' + id + '-rate').text(rate);
			}
		}
	}
};
	
var resource_generation_index = 0;
var resource_generation_max_index = 1000/tick_length;

function reset_resource_generation () {
	resource_generation_index = resource_generation_index == resource_generation_max_index ? 0 : resource_generation_index;
	for (var i = 0; i < resources.length; i++) {
		resources[i].gen_speed[resource_generation_index] = 0;
	}
}

// Called every tick to calculate resource production/consumption
function calculate_resources() {
	reset_resource_generation();
	for (var i = 0; i < glob.length; i++) {
		glob[i].tick();
	}
	resource_generation_index++;
}

// Create graphical resource list
function init_resource_list() {
	for (var i = 0; i < resources.length; i++) {		
		if (resources[i].active) {
			$('#resource-table').append ("<tr><td>" + resources[i].name + ":</td><td id='" + resources[i].id + "-quantity'></td><td id='" + resources[i].id + 
				"-capacity'></td><td id='" + resources[i].id + "-rate'></td></tr>");
		}
	}
}

function init_resources() {
	for (var i = 0; i < resources.length; i++) {
		resources[i].init();
	}
	init_resource_list();
}