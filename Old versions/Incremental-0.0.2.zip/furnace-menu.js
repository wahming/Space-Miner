function update_graphical_furnace_list() {
	if ($('#furnace-menu').css('display') == 'block') {
		for (var i = 0; i < furnace_types.length; i++) {
			for (var j = 0; j < furnace_types[i].collection.length; j++) {
				var fur = furnace_types[i].collection[j];
				var div_name = "div-furnace-" + fur.uid;
				
				document.getElementById(div_name + "-progress").value = fur.current_product_progress;
				document.getElementById(div_name + "-progress").max = fur.current_product_build_cost;
				$('#' + div_name + "-status").text (fur.status);
				if (fur.active == false && fur.current_product_progress == 0) {
					$('#' + div_name + "-resume").show();
				}
				$('#' + div_name + "-quantity").text(fur.current_product == null? "-" : fur.current_product.quantity);
			}
		}
	}
}


function init_furnace_list() {	
	$('#furnace-menu').remove();
	$('#furnace-menu').empty();
	$('#central-panel').append("<div id='furnace-menu' class='central-menu'></div>");	
	for (var i = 0; i < furnace_types.length; i++) {
		for (var j = 0; j < furnace_types[i].collection.length; j++) {
			add_to_furnace_list (furnace_types[i].collection[j]);
		}
	}
}

function get_smeltable_dropdown (div_name, fur) {
	var selected = fur.current_product == null ? null : fur.current_product.id; 
	var result = "<select id='" + div_name + "-dropdown' size=8>";
	
	if (selected == null) {
		result += "<option value='None' selected>Nothing</option>";
	} else {result += "<option value='None'>Nothing</option>";}
	
	for (var i = 0; i < resources.length; i++) {
		if (resources[i].smeltable) {
			if (resources[i].id == selected) {
				result += "<option value='" + resources[i].id + "' selected>" + resources[i].name + "</option>";
			} else {result += "<option id='" + div_name + "-option-" + i + "' value='" + resources[i].id + "'>" + resources[i].name + "</option>";}
		
			$(document).on ('mouseenter', "#" + div_name + "-option-" + i, function (e) {
				find_object (e.currentTarget.value).info();
			});
			
			$(document).on ('mouseleave', "#" + div_name + "-option-" + i, function (e) {
				//$('#info-table').empty();
			});
		}
	}
	
	result += "</select>";
		
	return result;
}

function add_to_furnace_list (fur) {
	var div_name = "div-furnace-" + fur.uid;
	
	$('#furnace-menu').append("<div class='list-div' id='" + div_name + "'></div>");
	
	$('#' + div_name).append ("<b>" + fur.name + "</b><br/><br/>");
	
	$('#' + div_name).append ("<table style='float:left;'><tr><td style='padding:0px; vertical-align:middle'>Currently smelting: <br/></td><td style='padding:0px;'  id='" + div_name + "-product'></td></tr></table>");
	$('#' + div_name).append ("<span style='float: right'>Quantity: <span id='" + div_name + "-quantity'>-</span></span><br/>");
	$('#' + div_name).append ("<span style='float: right'><input id='" + div_name + "-checkbox' type='checkbox'>Loop production</span>");
	$('#' + div_name + '-checkbox').prop('checked', fur.loop_production);
	$('#' + div_name).append ("<div id='" + div_name + "-buttons' style='clear:left'></div>");
	$('#' + div_name + '-buttons').append ("Capacity: " + fur.max_load + "<br/>");
	$('#' + div_name + '-buttons').append ("<a href='#' id='" + div_name + "-change-product'>(Change product)</a>");
	$('#' + div_name + '-buttons').append ("<a href='#' id='" + div_name + "-confirm' title='test'>(Confirm)</a>");
	$('#' + div_name + '-buttons').append ("<a href='#' id='" + div_name + "-cancel'>(Cancel)</a>");
	
	
	$('#' + div_name).append ("<br/>");
	$('#' + div_name).append ("Status: <span id='" + div_name + "-status'></span>&nbsp;<span id='" + div_name + "-resume'><a href='#'>(Resume)</a></span><br/>");
	$('#' + div_name).append ("<progress id='" + div_name + "-progress' class='progress' value=0 max_value=" + fur.current_product_build_cost + "></progress>");
	$('#' + div_name).append ("<p>-----</p>");
	

	$('#' + div_name + "-confirm").hide();
	$('#' + div_name + "-cancel").hide();
	$('#' + div_name + "-resume").hide();
	$('#' + div_name + "-product").text(fur.current_product == null? "Nothing" : fur.current_product.name);
	
	
	// Add button listener
	(function(fur, div_name) {
		$('#' + div_name + '-checkbox').click(function() {
			var $this = $(this);
			if ($this.is(':checked')) {
				fur.loop_production = true;
				// the checkbox was checked 
			} else {
				fur.loop_production = false;
				// the checkbox was unchecked
			}
		});
	}(fur, div_name));
		
	(function(fur, div_name) {
		$('#' + div_name + '-change-product').on('click', function () {
			$('#' + div_name + "-product").empty();
			$('#' + div_name + "-product").append (get_smeltable_dropdown (div_name, fur));
			$('#' + div_name + '-change-product').hide();
			$('#' + div_name + '-confirm').show();
			$('#' + div_name + '-cancel').show();
		});
	}(fur, div_name));
	
	(function(fur, div_name) {
		$('#' + div_name + '-confirm').on('click', function () {
			var selected = $('#' + div_name + "-dropdown").val();
			if (fur.current_product != selected) {
				if (selected != 'None') {
					fur.produce (selected);
					document.getElementById(div_name + "-progress").max = fur.current_product_build_cost;
				} else {
					fur.produce (null);
					document.getElementById(div_name + "-progress").max = 0;
				}
			}
			
			$('#' + div_name + "-product").text(fur.current_product == null? "Nothing" : fur.current_product.name);
			$('#' + div_name + '-confirm').hide();
			$('#' + div_name + '-cancel').hide();
			$('#' + div_name + "-dropdown").remove();
			$('#' + div_name + '-change-product').show();
			$('#' + div_name + "-resume").hide();
		});
	}(fur, div_name));
	
	(function(div_name) {
		$('#' + div_name + '-cancel').on('click', function () {
			$('#' + div_name + "-product").text(fur.current_product == null? "Nothing" : fur.current_product.name);
			$('#' + div_name + '-confirm').hide();
			$('#' + div_name + '-cancel').hide();
			$('#' + div_name + "-dropdown").remove();
			$('#' + div_name + '-change-product').show();
		});
	}(div_name));	
	
	(function(fur, div_name) {
		$('#' + div_name + '-resume').on('click', function () {
			$('#' + div_name + "-resume").hide();
			fur.active = true;
		});
	}(fur, div_name));
}


