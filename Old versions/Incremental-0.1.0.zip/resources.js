function resources_init () {
	resources_graphical_init();
}

function resources_graphical_init() {
	$('#resource-table').empty();
	for (var i = 0; i < resources.length; i++) {		
		if (resources[i].appear_in_game) {
			$('#resource-table').append ("<tr><td>" + resources[i].name + ":</td><td id='" + resources[i].id + "-quantity'></td><td id='" + resources[i].id + 
				"-capacity'></td><td id='" + resources[i].id + "-rate'></td></tr>");
		}
	}
}

function resources_graphical_update() {
	for (var i = 0; i < resources.length; i++) {
		if (resources[i].appear_in_game) {
			var quantity = resources[i].quantity;
			var id = resources[i].id;
			
			$('#' + id + '-quantity').text((quantity < 0 ? -1 * quantity : quantity).toFixed(0));		// Remove minus signs, usually show up on zeroes (floating point error)
			
			if (resources[i].capacity <= 0) {
				$('#' + id + '-quantity').append (" " + resources[i].unit);
			} else {
				var storage = "/" + resources[i].capacity + " " + resources[i].unit;
				$('#' + id + '-capacity').empty();
				$('#' + id + '-capacity').append(storage);
			}
			
			$('#' + id + '-rate').empty();
			var rate = resources_get_generation_speed.call(resources[i]).toFixed(1);
			if (id != "storage") {
				if (rate > 0) {rate = "(+" + rate + "/s)";}
				else {rate = "(" + rate + "/s)";}
				
				$('#' + id + '-rate').text(rate);
			}
		}
	}
};

function resources_get_generation_speed () {
	var result = 0;
	var gen_speed = this.generation_speed_array;
	
	if (gen_speed.length == 0) {return 0;}
	for (i in gen_speed) {
		result += gen_speed[i];
	}
	return result / gen_speed.length * 1000/tick_length;
}

/*
//var resource_generation_index = 0;
//var resource_generation_max_index = 1000/tick_length;

function reset_resource_generation () {
	resource_generation_index = resource_generation_index == resource_generation_max_index ? 0 : resource_generation_index;
	for (var i = 0; i < resources.length; i++) {
		resources[i].gen_speed[resource_generation_index] = 0;
	}
}

// Called every tick to calculate resource production/consumption
function calculate_resources() {
	reset_resource_generation();
	for (var i = 0; i < glob.length; i++) {
		glob[i].tick();
	}
	resource_generation_index++;
}

*/