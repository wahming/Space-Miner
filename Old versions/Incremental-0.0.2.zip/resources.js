function update_graphical_resource_list() {
	for (var i = 0; i < resources.length; i++) {
		
		if (resources[i].active) {
			var quantity = resources[i].quantity;
			var id = resources[i].id;
			
			$('#' + id + '-quantity').text((quantity < 0 ? -1 * quantity : quantity).toFixed(0));		// Remove minus signs, usually show up on zeroes (floating point error)
			
			if (resources[i].storage == 0) {
				$('#' + id + '-quantity').append (" " + resources[i].unit);
			}
			
			if (resources[i].capacity > 0) {
				var storage = "/" + resources[i].storage + " " + resources[i].unit;
				$('#' + id + '-storage').empty();
				$('#' + id + '-storage').append(storage);
			}
			
			$('#' + id + '-rate').empty();
			var rate = resources[i].generation_speed().toFixed(1);
			if (rate != 0) {
				if (rate > 0) {rate = "(+" + rate + "/s)";}
				else {rate = "(" + rate + "/s)";}
				
				$('#' + id + '-rate').text(rate);
			}
		}
	}
};
	
var resource_generation_index = 0;
var resource_generation_max_index = 1000/tick_length;

function reset_resource_generation () {
	resource_generation_index = resource_generation_index == resource_generation_max_index ? 0 : resource_generation_index;
	for (var i = 0; i < resources.length; i++) {
		resources[i].gen_speed[resource_generation_index] = 0;
	}
}

// Called every tick to calculate resource production/consumption
function calculate_resources() {
	reset_resource_generation();
	for (var i = 0; i < glob.length; i++) {
		glob[i].tick();
	}
	resource_generation_index++;
}

// Create graphical resource list
function init_resource_list() {
	$('#resource-table').empty();
	for (var i = 0; i < resources.length; i++) {		
		if (resources[i].active) {
			$('#resource-table').append ("<tr><td>" + resources[i].name + ":</td><td id='" + resources[i].id + "-quantity'></td><td id='" + resources[i].id + 
				"-capacity'></td><td id='" + resources[i].id + "-rate'></td></tr>");
		}
	}
}
