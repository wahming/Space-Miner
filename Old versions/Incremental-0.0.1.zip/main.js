var timer = (new Date()).getTime();
time_change = 0;

// Run UI update code every 100ms
window.setInterval(function () {
	time_change = (new Date()).getTime() - timer + (time_change % tick_length);
	timer = (new Date()).getTime();
		
	for (var i = 1; i <= time_change/tick_length; i++) {
		calculate_resources();
		update_graphical_resource_list();
		update_graphical_build_list();
		update_graphical_fabricator_list();
		update_graphical_products_list();
		update_graphical_furnace_list();
	}
	
	//console.log ((new Date()).getTime() - time_start);
	
}, tick_length);

window.setInterval(function () {
	/*for (var i = 0; i < glob.length; i++) {
		localStorage["glob"+i] = JSON.stringify(glob[i]);
	}*/
	//localStorage["glob"] = JSON.stringify(glob);
}, 5000);

// init 

init_resource_list();
init_build_list();
init_products_list();
init_fabricator_list();
init_furnace_list();

// Create starting objects
for (var i = 0; i < glob.length; i++) {
	glob[i].init();
}

for (var i = 0; i < localStorage.length; i++) {
	if (localStorage.getItem ("glob" + i) != null) {
		//glob[i] = $.extend (Object.create (game_object), JSON.parse (localStorage.getItem ("glob" + i)));
	}
}

if (localStorage.length > 0) {
	//glob = [];
	//glob = JSON.parse (localStorage.getItem ("glob"));
}